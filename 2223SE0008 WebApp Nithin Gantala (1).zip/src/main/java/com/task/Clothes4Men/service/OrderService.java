package com.task.Clothes4Men.service;

import java.util.List;

import com.task.Clothes4Men.domain.Order;
import com.task.Clothes4Men.domain.Payment;
import com.task.Clothes4Men.domain.Shipping;
import com.task.Clothes4Men.domain.ShoppingCart;
import com.task.Clothes4Men.domain.User;

public interface OrderService {

	Order createOrder(ShoppingCart shoppingCart, Shipping shippingAddress, Payment payment, User user);
	
	List<Order> findByUser(User user);
	
	Order findOrderWithDetails(Long id);
}
