package com.task.Clothes4Men.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/predict")
public class PredController {
    
}
